import java.util.*;
public class CellPhoneService {
    public static void main (String args[]) {
        // Write your code here

        Scanner scanner = new Scanner(System.in);
        double integer;
        System.out.println("Enter a number between three and four:");
        integer = scanner.nextDouble();
        if(integer <= 3 || integer >= 4)
            System.out.println("Error");
    }
}