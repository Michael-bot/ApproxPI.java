using system
{
  namespace CSharp
  {
    public class Program
    {
      public static void Main(string[] args)
      {
        int [] numbers = new int[5];
        numbers[0] = 10;
        numbers[1] = 7;
        numbers[2] = 2;
        numbers[3] = 5;
        numbers[4] = 9;

        Array.sort(numbers);

        Array.reverse(numbers);

        foreach (var number in numbers)
        {
          Console.WriteLine(number);
        }
        
        string[] studentNames = new string [10];
        double[] studentResults = new double[4];
        {
          5, 6.5, 10, 11
        }

      }
    }
  }
}




//different examples

using System;

static class MainClass
{
  static void Main()
  {
    int[] ints = new int[] {25, 34, 32};
    ints[3] = 99; // this would not work

    ArrayList myPartyAges= new ArrayList();
    myPartyAges.Add(25);
    myPartyAges.Add(34);
    myPartyAges.Add(32);
    myPatryAges.Add(99);

    foreach(int age in myPartyAges)
    Console.WriteLine(age);

  }
}

using System;
using System.Collections;
using System.Collections.Generic;

static class MainClass
{
  static void Main()
  {
    System.Collections.Generic.
    int[] ints = new int[] {25, 34, 32};
    ints[3] = 99; // this would not work

    ArrayList myPartyAges= new ArrayList();
    myPartyAges.Add(25);
    myPartyAges.Add(34);
    myPartyAges.Add("Billy");// in here this would go unnoticed
    myPartyAges.Add(32);
    myPatryAges.Add(99);

    List<int> myPartyAges2 = new list<int>();

    myPartyAges.Add(25);
    myPartyAges.Add(34);
    myPartyAges.Add("Billy"); // because this is in a list it will be noticed
    myPartyAges.Add(32);
    myPatryAges.Add(99);

    foreach(int age in myPartyAges)
    Console.WriteLine(age);

  }
}


